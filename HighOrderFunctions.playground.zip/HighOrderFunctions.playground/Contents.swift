
/// - High Order Functions

// Map

let priceList = [10.5, 30.0, 21.2, 16.0, 3.0, 43,9]

let totalArray = priceList.map ({"\($0 + 1) EUR"})
let discountPrices = priceList.map {$0 * 0.9}
let multiNumbers = discountPrices.allSatisfy {$0 >= 22.5}


var cast = ["Ozgur", "Luiza", "Ezgi", "Aysel"]

let lowercase = cast.map { $0.lowercased() }
let letterCounts = cast.map { $0.count }
print(lowercase)


// FlatMap

let arrayOfDwarfArrays = [
    ["Sleepy", "Grumpy", "Doc",],
    ["Thorin", "Nori", "Gimli"]
]

let dwarvesAfterM = arrayOfDwarfArrays.flatMap {
    $0.filter { $0 > "M" }
}.sorted()
let dwarf = arrayOfDwarfArrays.flatMap {$0}


let results = [[5,2,7], [4,8], [9,1,3]]

let allResults = results.flatMap {$0}.sorted(by: >)
print(allResults)
    
// CompactMap

let userInput = ["stone", "32", "37,5", "thirty", "10"]

let validInput = userInput.compactMap { input in Int(input)}
    .filter {$0 > 30}
print(validInput)


// Reduce

let avg:Double = priceList.reduce(0.0) { $0 + ($1 / Double(priceList.count)) }
let newNames = arrayOfDwarfArrays.reduce(" ") {_,_ in String.init("Dwarf")}
let names = priceList.reduce(100) {$0 + $1}
print(names)


// Filter

let namesAndAges = ["Nori": 30, "Grumpy": 35, "Doc": 55, "Thorin": 17]

let changedAges = namesAndAges.filter { $0.value  % 2 == 0} //$0.value == $1
print(changedAges)


